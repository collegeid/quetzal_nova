<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="py-10 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
        <div class="max-w-7xl mx-auto px-6 lg:px-8 space-y-8">
      
      
        <div class="mb-4 flex items-center space-x-2">
            <form method="GET" action="<?php echo e(route('laporan.download')); ?>">
                <label for="month" class="mr-2 font-medium"> Periode:</label>
                <select id="month" name="month" class="border rounded px-2 py-1">
                    <?php $__currentLoopData = $bulanTersedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bulan); ?>" <?php echo e(request('month') == $bulan ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::parse($bulan.'-01')->format('F Y')); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded">
                    Export PDF
                </button>
            </form>
        </div>


          <!-- Statistik Cards -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php
                            $cards = [
                            ['title'=>'Total Data Cacat','value'=>$totalCacat,'color'=>'from-blue-600 to-indigo-700 text-white'],
                            ['title'=>'Total Jenis Cacat','value'=>$totalJenis,'color'=>'from-teal-500 to-green-600 text-white'],
                            ['title'=>'Total User','value'=>$totalUser,'color'=>'from-gray-500 to-gray-700 text-white'],
                            ['title'=>'Verifikasi Valid','value'=>$verifikasiValid,'color'=>'from-blue-400 to-blue-600 text-white'],
                            ['title'=>'Verifikasi Belum Valid','value'=>$verifikasiBelum,'color'=>'from-red-500 to-red-700 text-white'],
                            ['title'=>'Status Sistem','value'=>$statusSistem,'color'=>'from-amber-500 to-yellow-600 text-gray-900'],
                            ['title'=>'Cacat Terbanyak','value'=>$jenisTerbanyak,'color'=>'from-purple-600 to-indigo-800 text-white'],
                            ['title'=>'Mesin Bermasalah Terbaru','value'=>$mesinBermasalah,'color'=>'from-gray-700 to-gray-900 text-white']
                        ];

                    ?>

                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-gradient-to-r <?php echo e($card['color']); ?> rounded-2xl text-white shadow-lg p-5 transform hover:scale-[1.03] transition">
                            <p class="text-sm uppercase tracking-wide opacity-80"><?php echo e($card['title']); ?></p>
                            <p class="text-1xl font-semibold mt-1"><?php echo e($card['value']); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


      

            <!-- Chart Section -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-6">
                <!-- Grafik Tren Produksi -->
                <div class="bg-white rounded-2xl p-6 shadow-md border border-gray-100">
                    <div class="flex items-center gap-4 mb-4">
                            <select id="rangeFilter" class="border border-gray-300 rounded-lg p-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-400">
                                <option value="day" selected>Per Hari</option>
                                <option value="week">Per Minggu</option>
                                <option value="month">Per Bulan</option>
                                <option value="year">Per Tahun</option>
                            </select>

                            <button id="filterBtn" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2 rounded-lg shadow transition duration-200">
                                Terapkan
                            </button>
                     </div>

                        <h4 class="text-lg font-semibold text-gray-800 mb-4">📈 Tren Data Cacat</h4>
                        <canvas id="trendChart" height="150"></canvas>
                    </div>


                    <!-- Grafik Distribusi Jenis Cacat -->
                    <div class="bg-white rounded-2xl p-6 shadow-md border border-gray-100">
                        <h4 class="text-lg font-semibold text-gray-800 mb-4">📊 Distribusi Jenis Cacat</h4>
                        <canvas id="jenisChart" height="150"></canvas>
                    </div>
              </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-6">
                <!-- Grafik Status Verifikasi -->
                <div class="bg-white rounded-2xl p-6 shadow-md border border-gray-100" style="max-height: 400px; overflow-y: auto;">
                <h4 class="text-lg font-semibold text-gray-800 mb-4">🧾 Status Verifikasi</h4>
                    <canvas id="verifikasiChart" height="150"></canvas>
                </div>

             <!-- Grafik Top 5 Mesin Rusak -->
             <div class="bg-white rounded-2xl p-6 shadow-md border border-gray-100" style="max-height: 400px; overflow-y: auto;">
                <h4 class="text-lg font-semibold text-gray-800 mb-4">⚙️ Top Mesin Rusak</h4>
                <canvas id="mesinChart"></canvas>
            </div>
           


            <!-- Footer -->
            <div class="text-center text-gray-400 text-sm pt-10">
                © <?php echo e(date('Y')); ?> <span class="font-semibold text-indigo-600">Qual Nova QC System</span> — Developed by <span class="font-medium">Quetzal Team's</span>
            </div>
        </div>
    </div>

    <!-- Chart.js Scripts -->
    <script>
   
        // Chart 1: Trend Chart: Harian, Mingguan, Bulanan, Tahunan

        const ctx = document.getElementById('trendChart').getContext('2d');
            let trendChart;

            async function loadTrendChart(range = 'day') {
                const res = await fetch(`/dashboard/chart-trend?range=${range}`);
                const json = await res.json();

                if (trendChart) trendChart.destroy();

                trendChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: json.labels,
                        datasets: [{
                            label: 'Jumlah Cacat',
                            data: json.totals,
                            borderColor: '#3B82F6',
                            backgroundColor: 'rgba(59,130,246,0.2)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointRadius: 4,
                            pointBackgroundColor: '#1D4ED8'
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { display: false }},
                        scales: {
                            y: { beginAtZero: true, title: { display: true, text: 'Jumlah Cacat' }},
                            x: { title: { display: true, text: 'Periode' }}
                        }
                    }
                });
            }

            // initial load
            loadTrendChart();

            // filter button
            document.getElementById('filterBtn').addEventListener('click', () => {
                const range = document.getElementById('rangeFilter').value;
                loadTrendChart(range);
            });

        // 🔹 Chart 2: Distribusi Jenis Cacat
        new Chart(document.getElementById('jenisChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($namaJenisCacat); ?>,
                datasets: [{
                    label: 'Jumlah',
                    data: <?php echo json_encode($jumlahPerJenis); ?>,
                    backgroundColor: ['#6366F1','#10B981','#F59E0B','#EF4444','#3B82F6','#8B5CF6']
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false }},
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Jumlah Cacat' }},
                    x: { title: { display: true, text: 'Jenis Cacat' }}
                }
            }
        });

     // 🔹 Chart 3: Status Verifikasi
const ctxVerifikasi = document.getElementById('verifikasiChart').getContext('2d');

        new Chart(ctxVerifikasi, {
            type: 'bar', // ganti dari 'doughnut' ke 'bar'
            data: {
                labels: ['Valid', 'Belum Valid'],
                datasets: [{
                    label: 'Jumlah Verifikasi',
                    data: [<?php echo e($verifikasiValid); ?>, <?php echo e($verifikasiBelum); ?>],
                    backgroundColor: ['#22C55E', '#f5d742'],
                    borderColor: ['#16A34A', '#D4B500'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Data'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Status Verifikasi'
                        }
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y + ' data';
                            }
                        }
                    }
                }
            }
        });

        const ctxMesin = document.getElementById('mesinChart').getContext('2d');

            
        new Chart(ctxMesin, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($namaMesin, 15, 512) ?>,
                datasets: [{
                    label: 'Jumlah Cacat Valid',
                    data: <?php echo json_encode($jumlahCacatMesin, 15, 512) ?>,
                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                indexAxis: 'y', // horizontal bar
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Cacat Valid'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Mesin'
                        }
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.parsed.x + ' cacat';
                            }
                        }
                    }
                }
            }
        });


        function updateStatusSistem() {
            fetch('/dashboard/status-sistem')
                .then(res => res.json())
                .then(data => {
                    document.getElementById('statusSistem').innerText = data.status;
                });
        }

        // update tiap 5 detik
        setInterval(updateStatusSistem, 500);
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/vj007/github/PROJECT/qualnova-qc/resources/views/dashboard/index.blade.php ENDPATH**/ ?>